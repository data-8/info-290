test = {
  'name': 'Question 2_2',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> elements_of_some_numbers
          English name for position | Index | Element
          first                     | 0     | -1
          second                    | 1     | -3
          third                     | 2     | -6
          fourth                    | 3     | -10
          fifth                     | 4     | -15
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
