test = {
  'name': 'Question 3_11',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> lower_bound > 80
          True
          """,
          'hidden': False,
          'locked': False
        },
        {
          'code': r"""
          >>> upper_bound < 955
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
